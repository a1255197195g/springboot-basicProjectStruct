package com.kb.treatment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreatmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(TreatmentApplication.class, args);
    }
}
